package com.example.ecommerce.service;

import com.example.ecommerce.model.Product;
import com.example.ecommerce.repository.ProductRepository; // Import ang bagong repository
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

/**
 * Service handling business logic for Products using Spring Data JPA.
 */
@Service
public class ProductService {

    @Autowired 
    private ProductRepository productRepository; // Pinalitan ang ArrayList

    /** Retrieves all products from the database[cite: 1] */
    public List<Product> getAllProducts() { 
        return productRepository.findAll(); 
    }

    /** Finds a product by its unique ID in the database[cite: 1] */
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    /** Creates and stores a new product in the database[cite: 1] */
    public Product createProduct(Product product) {
        return productRepository.save(product); 
    }

    /** Replaces an existing product in the database[cite: 1] */
    public Optional<Product> updateProduct(Long id, Product updated) {
        return productRepository.findById(id).map(existing -> {
            existing.setName(updated.getName());
            existing.setDescription(updated.getDescription());
            existing.setPrice(updated.getPrice());
            existing.setCategory(updated.getCategory());
            existing.setStockQuantity(updated.getStockQuantity());
            existing.setImageUrl(updated.getImageUrl());
            return productRepository.save(existing); // I-save ang changes sa DB[cite: 1]
        });
    }

    /** Deletes a product by ID from the database[cite: 1] */
    public boolean deleteProduct(Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return true;
        }
        return false;
    }
}