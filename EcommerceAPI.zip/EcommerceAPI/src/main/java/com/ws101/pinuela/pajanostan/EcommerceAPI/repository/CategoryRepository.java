package com.example.ecommerce.repository;

import com.example.ecommerce.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for Category entity.[cite: 1]
 */
@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
}