/* TASK 5 & 6: FETCH API & ASYNCHRONOUS DATA */
const API_URL = "http://localhost:8080/api/v1/products";
let products = []; // Now populated via the database
let cart = JSON.parse(localStorage.getItem('techstore_cart')) || [];

/**
 * Task 5 requirement: Utility function using async/await with error handling.
 */
async function fetchProducts() {
    try {
        const response = await fetch(API_URL);
        
        // Manual check for 404 or 500 errors
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        products = await response.json();
        renderProducts(products); // Render once data is received
        
    } catch (error) {
        console.error("Failed to fetch products:", error);
        const grid = document.querySelector('.product-grid');
        if (grid) {
            grid.innerHTML = `<p class="error">Unable to load products. Please check if the backend is running.</p>`;
        }
    }
}

/* TASK 2: DYNAMIC PRODUCT RENDERING (Updated for Fetch) */
function renderProducts(productsList) {
    const grid = document.querySelector('.product-grid');
    if (!grid) return;
    grid.innerHTML = "";

    // Handle "Empty State" if API returns no products
    if (productsList.length === 0) {
        grid.innerHTML = "<p>No products available at the moment.</p>";
        return;
    }

    productsList.forEach(p => {
        const article = document.createElement('article');
        
        const img = document.createElement('img');
        // Use p.imageUrl from your JPA Product model
        img.src = p.imageUrl || "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400";
        
        const infoDiv = document.createElement('div');
        infoDiv.className = "product-info";

        const h3 = document.createElement('h3');
        h3.textContent = p.name;

        const pricePara = document.createElement('p');
        pricePara.className = "price";
        pricePara.textContent = `$${p.price}`;

        const btn = document.createElement('button');
        btn.className = "shimmer-btn add-to-cart";
        btn.textContent = "Add to Cart";
        btn.setAttribute('data-id', p.id);

        infoDiv.appendChild(h3);
        infoDiv.appendChild(pricePara);
        article.appendChild(img);
        article.appendChild(infoDiv);
        article.appendChild(btn);
        grid.appendChild(article);
    });
}

/* TASK 3: EVENT HANDLING & THE CART (Delegation) */
document.body.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart')) {
        const id = parseInt(e.target.getAttribute('data-id'));
        const product = products.find(prod => prod.id === id);
        
        if (product) {
            const existing = cart.find(item => item.id === id);
            if (existing) {
                existing.quantity += 1;
            } else {
                cart.push({ ...product, quantity: 1 });
            }
            
            localStorage.setItem('techstore_cart', JSON.stringify(cart));
            
            // Interactive Feedback
            const card = e.target.closest('article');
            card.classList.add('fade-in');
            setTimeout(() => card.classList.remove('fade-in'), 500);

            setTimeout(() => { window.location.href = 'cart.html'; }, 400);
        }
    }
});

/* TASK 3.3: RENDERING THE CART (cart.html) */
function renderCart() {
    const container = document.getElementById('cart-items-container');
    const totalEl = document.getElementById('cart-total');
    if (!container) return;

    container.innerHTML = cart.length === 0 ? "<p>Your bag is empty.</p>" : "";
    
    cart.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = "cart-item";
        div.innerHTML = `
            <img src="${item.imageUrl}" width="80" style="border-radius: 10px;">
            <div style="flex:1">
                <h4>${item.name}</h4>
                <p>$${item.price}</p>
            </div>
            <input type="number" value="${item.quantity}" min="0" class="qty-change" data-index="${index}">
        `;
        container.appendChild(div);
    });

    const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    if (totalEl) totalEl.textContent = `Total: $${total.toFixed(2)}`;
}

/* TASK 3.4: QUANTITY ADJUSTMENT */
document.addEventListener('change', (e) => {
    if (e.target.classList.contains('qty-change')) {
        const idx = e.target.dataset.index;
        const val = parseInt(e.target.value);
        if (val <= 0) {
            cart.splice(idx, 1);
        } else {
            cart[idx].quantity = val;
        }
        localStorage.setItem('techstore_cart', JSON.stringify(cart));
        renderCart();
    }
});

/* TASK 4: FORM VALIDATION (checkout.html) */
const form = document.querySelector('form');
if (form) {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const nameInput = document.querySelector('input[placeholder="Full Name"]');
        if (nameInput.value.trim() === "") {
            nameInput.classList.add('error');
        } else {
            alert("Order Successful!");
            cart = [];
            localStorage.removeItem('techstore_cart');
            window.location.href = 'account.html';
        }
    });
}

/* TASK 5: USER ACCOUNT */
function loadUser() {
    const greeting = document.getElementById('user-greeting');
    if (greeting) {
        greeting.textContent = `Welcome back, Stephanie!`;
    }
}

// Initialization
window.onload = () => {
    fetchProducts(); // Call fetch on page load
    renderCart();
    loadUser();
};