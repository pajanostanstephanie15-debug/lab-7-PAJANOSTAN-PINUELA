package com.example.ecommerce.model;

import jakarta.validation.constraints.*;
import lombok.*;

/**
 * Represents an e-commerce product entity.
 */
@Entity
@Table(name = "products")
@Getter 
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Product name is required")
    @Size(min = 2, message = "Name must be at least 2 characters")
    private String name;

    private String description;

    @Positive(message = "Price must be a positive number")
    private double price;

   @ManytoOne(fetch = FetchType.LAZY)
   @JoinColumn(name = "category_id", nullable = false)
   private Category category;

    @Min(value = 0, message = "Stock cannot be negative")
    private int stockQuantity;

    private String imageUrl;
}

