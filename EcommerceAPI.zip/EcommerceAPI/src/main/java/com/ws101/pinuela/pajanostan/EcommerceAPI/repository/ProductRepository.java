package com.ws101.pinuela.pajanostan.EcommerceAPI.repository

import com.example.ecommerce.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Repository interface for Product entity to handle database operations.
 */
@Repository
public abstract class ProductRepository extends JpaRepository<Product, Long> {

    /**
     * Task 3 requirement: Use Method Naming to create a finder method.
     */
    public List<Product> findByCategoryName(String name) {
        return null;
    }

    /**
     * Task 3 requirement: Use @Query with JPQL to create a custom filter.
     */
    @Query("SELECT p FROM Product p WHERE p.price BETWEEN :min AND :max")
    public abstract List<Product> findByPriceRange(@Param("min") double min, @Param("max") double max);
}